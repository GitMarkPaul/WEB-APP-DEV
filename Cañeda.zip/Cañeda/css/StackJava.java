package stack.java;
import java.util.Scanner;
public class StackJava {
    
    Scanner in = new Scanner(System.in);
    
    public int array[];
    public int deq;
    public int top = 0;
    public int size;
    public int capacity;
    public String[] storage;
    
   
    public StackJava(int size){
    capacity = size;
    storage = new String[capacity];    
    }
      public void show(){
    
    for(int h = capacity-1; h >=0; h--){
        System.out.println("Stack["+ h +"] = " + storage[h]);
        
      }
        System.out.println();
    }
      private boolean isEmpty(){
        
        if(storage[0] == null){  
            System.out.println("STORAGE IS EMPTY.");
           System.out.println();
        
        return true;
    }
    return false;
}
    private boolean isFull(){
        if(top == capacity){
            System.out.println("STORAGE IS FULL.");
            System.out.println();
            return true;
            
        }
        return false;
    }
       public void push(String value) {
    if (isFull()) {
      // print error message
      System.out.println("ADD FAILED");
        System.out.println();
    } else {
      System.out.println("... trying to push on stack[" + top + "] ...");
      storage[top] = value;
      top++;
      /* increment or decrement top*/;
      System.out.println(value + " was successfully added.");
      System.out.println();
    }
  }

     public void pop() {
    if (isEmpty()) {
      // print error message
      System.out.println("REMOVE FAILED");
        System.out.println();
    } else {
      System.out.println("... trying to pop stack[" + (top-1) + "] ...");
      storage[top] = null;
      top--;
      /* increment or decrement top*/;
      System.out.println(storage[top] + " was successfully removed.");
      System.out.println();
    }
  }

      public void peek() {
    if (array[top] == array[0]) {
      System.out.println("PEEK FRONT TOP = " + array[top]);
      System.out.println();
    } else {
      System.out.println("PEEK FRONT TOP = " + array[top-1]);
      System.out.println();
    }
  }  
    
    
     public void Dequeue(int size2){
        
      	for(int w = 0; w < deq; w++){
			for(int e = 0; e < size2-1 ;e++){
				array[e]= array[e+1];
			}
                }
                        for(int e = size2-deq; e < size2; e++ ){
			array[e]=0;
                        }
                }
     public void Enqueue(int size3){
         
      	for(int r = size3 - deq; r < size3; r++){
			System.out.print("Queue [" + (r+1) + "]: ");
			array[r] = in.nextInt();
		}

         
     }
    
    public static void main(String[] args) {
        
        
        int size = 0;
        
        StackJava x = new StackJava(10);
        
      	
		for(int q = 0; q < size; q++){
			System.out.print("INDEX [" + (q+1) + "]: ");
			x.array[q] = x.in.nextInt();
                        
                }
                
                x.Dequeue(size);
		
		for(int q = 0; q < size; q++){
			System.out.print("\nINDEX [" + (q+1) + "]: " + x.array[q]);
                        
		}
		x.Enqueue(size);
                
      	for(int q = 0; q < size; q++){
			System.out.print("\nINDEX [" + (q+1) + "]: " + x.array[q]);
		} 
        x.peek();
                
                  StackJava storage = new StackJava(size);
                  
                  System.out.println("\n\nNUMBER OF INDEX IS = " + storage.capacity);
    System.out.println();
    storage.show();
    // show empty stack
    storage.pop();
    // try removing on an empty stack
    storage.peek();
    // peek top element of an empty stack
    storage.push("1");
    storage.show();
    // show the updated stack
    storage.peek();
    // peek if top element is "one"
    storage.push("2");
    storage.show();
    // show the updated stack
    storage.peek();
    // peek if top element is "two"
    storage.push("3");
    storage.show();
    // show the updated stack
    storage.peek();
    // peek if top element is "three"
    storage.push("4");
    // show the updated stack
    storage.show();
    storage.push("5");
    storage.show();
    // show the updated stack
    storage.pop();
    // try removing "five"
    storage.push("6"); 
    storage.push("7"); 
    storage.push("8"); 
    storage.push("9"); 
    storage.push("10"); 
    storage.show();
    storage.pop();
    storage.push("11"); 
    storage.show();
    storage.push("12");
    storage.show();
  
        
    }
}